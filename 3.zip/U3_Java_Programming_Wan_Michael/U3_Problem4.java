/*
Michael Wan
10/08/17

CSC 201 (E05M)
Unit 3: Programming Problem 4 (Builder)
U3_Problem4.java

Purpose:
Create a class called Builder that appends a series of Strings which are
entered as inputs from user. The program will accept a String "Java is fun!"
and determine the capacity of entered String then append a second String:
"I love it!" to the first String. After that, enter a String "Yes, " and
insert this String between the first and second Strings so the complete final
output is: "Java is fun. Yes, I love it!"
*/

/* Pseudocode:
Ask user for "Java is fun!" input
WHILE user input is not "Java is fun!", continue receiving user input
Utilize StringBuilder to accept "Java is fun!" String
Determine capacity of "Java is fun!"
Append "I love it!" using StringBuilder
Ask user for "Yes, " input
WHILE user input is not "Yes, ", continue receiving user input
Insert "Yes, " between first and second strings using capacity of first
Display final string result
*/

import java.util.Scanner;

public class U3_Problem4 {

  public static void main(String[] args) {

    Scanner input = new Scanner(System.in);

    // ask user for "Java is fun!" input
    System.out.println("\nPlease enter a string: ");
    String s1 = input.nextLine();

    // WHILE user input is not "Java is fun!", continue receiving user input
    while (!s1.equals("Java is fun!")) {
      System.out.println("String not accepted, please try again: ");
      s1 = input.nextLine();
    }

    // utilize StringBuilder to accept "Java is fun!" String
    StringBuilder builder = new StringBuilder(s1);
    // determine capacity of "Java is fun!"
    int capacity = s1.length();
    // Append "I love it!" using StringBuilder
    builder.append("I love it!");

    // ask user for "Yes, " input
    System.out.println("Enter 'Yes, ' without the single quotations: ");
    String s2 = input.nextLine();

    // WHILE user input is not "Yes, ", continue receiving user input
    while (!s2.equals("Yes, ")) {
      System.out.println("Error, please try again: ");
      s2 = input.nextLine();
    }

    // Insert "Yes, " between first and second strings using capacity of first
    builder.insert(capacity, s2);

    // Display final string result
    System.out.println(builder + "\n");

  }
}
