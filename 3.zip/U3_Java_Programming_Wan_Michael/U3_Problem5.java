/*
Michael Wan
10/08/17

CSC 201 (E05M)
Unit 3: Programming Problem 5 (CharacterArray)
U3_Problem5.java

Purpose:
Create a program that will accept a String and store it into a character array.
String: 6901 Sudley Road Manassas VA
Display each original character, determine and display whether each character
is a digit or a letter, and redisplay the character according to the following:
  lower case becomes upper case
  upper case becomes lower case
  digit becomes asterisk *
*/

/* Pseudocode:
INIT string variable
INIT char array and convert string to be stored in array
FOR each index in array chars
  IF char is letter
    DISPLAY original char
    IF uppercase, change to lower and display
    ELSE must be lowercase, change to upper and display
    END IF
  ELSE IF char is digit
    DISPLAY original char
    DISPLAY digit as an asterisk
    END ELSE IF
  ELSE blank line for empty spaces
    END ELSE
END FOR
*/

public class U3_Problem5 {

  public static void main(String[] args) {

    // INIT string variable
    String s1 = "6901 Sudley Road Manassas VA";
    // INIT char array and convert string to be stored in array
    char[] chars = s1.toCharArray();

    // FOR each index in array chars
    for (int i=0; i<chars.length; i++) {
      // IF char is letter
      if (Character.isLetter(chars[i])) {
        // DISPLAY original char
        System.out.print("\n" + chars[i] + "  -  Letter");
        // IF uppercase, change to lower and display
        if (Character.isUpperCase(chars[i])) {
          System.out.print("  -  " + Character.toLowerCase(chars[i]));
        }
        else { // ELSE must be lowercase, change to upper and display
          System.out.print("  -  " + Character.toUpperCase(chars[i]));
        }
      } // END IF
      // ELSE IF char is digit
      else if (Character.isDigit(chars[i])) {
        // DISPLAY original char
        System.out.print("\n" + chars[i] + "  -   Digit");
        // DISPLAY digit as an asterisk
        System.out.print("  -  *");
      } // END ELSE IF
      else { // blank line for empty spaces
        System.out.println("");
      } // END ELSE
    } // END FOR
    System.out.println("\n");

  }
}
