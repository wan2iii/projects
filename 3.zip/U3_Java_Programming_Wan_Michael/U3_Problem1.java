/*
Michael Wan
10/08/17

CSC 201 (E05M)
Unit 3: Programming Problem 1 (High School Locker)
U3_Problem1.java

Purpose:
Create a class to represent lockers for high school students and a class
for the combination lock on those lockers as an attribute of it. Simulate
your typical high school lockers and combination locks given to students.
Create appropriate methods for both classes along with a main method
in a separate class.
*/

/* Pseudocode:
1) Create CombinationLock class and define methods
  combination lock - 3 numbers 0-39, left then right then left, reset = 0
  constructor w/ no input arguments
  constructor w/ arguments for all attributes
  appropriate to set and get methods
  method to print out all attributes
  resetDial method resets dial to 0
  turnLeft method turn dial # of ticks left from current
  turnRight method turn dial # of ticks right from current
  openLock method 3 input arguments passed as combination, return T/F
2) Create Locker class and define methods with CombinationLock as an attribute
  locker - locker number, student name, # of books, combination lock
  include attribute type CombinationLock
  constructor w/ no input arguments
  constructor w/ arguments for all attributes
  appropriate set and get methods
  method to print out all attributes
  putBookInLocker method adds one book, no input arg, no return
  removeBookFromLocker method, remove one book, return T/F
  openLocker method, reads 3 ints, print success/failure
3) Create main method and perform requested tasks
  main method separate from Locker and CombinationLock classes
  creates locker #100 for Mickey Mouse (combination: 28-17-39), 3 books
  creates locker #275 for Donald Duck (combination: 35-16-27), 0 books
  try to open Mickey locker using 15, 18, 18
  add three books to Mickey's locker
  remove one book from Donald's locker
  print states of both lockers to console
*/

import java.util.Scanner;

public class U3_Problem1 {

  public static void main(String[] args) {

    // main method separate from Locker and CombinationLock classes
    // creates locker #100 for Mickey Mouse (combination: 28-17-39), 3 books
    // creates locker #275 for Donald Duck (combination: 35-16-27), 0 books
    // try to open Mickey locker using 15, 18, 18
    // add three books to Mickey's locker
    // remove one book from Donald's locker
    // print states of both lockers to console

    // creates locker #100 for Mickey Mouse (combination: 28-17-39), 3 books
    Locker M = new Locker(100, "Mickey Mouse", new CombinationLock(28,17,39,0), 3);
    // creates locker #275 for Donald Duck (combination: 35-16-27), 0 books
    Locker D = new Locker(275, "Donald Duck", new CombinationLock(35,16,27,0), 0);
    // try to open Mickey locker using 15, 18, 18
    M.openLocker();
    // add three books to Mickey's locker
    M.putBookInLocker();
    M.putBookInLocker();
    M.putBookInLocker();
    // remove one book from Donald's locker
    D.removeBookFromLocker();
    // print states of both lockers to console
    System.out.println(M.printLocker());
    System.out.println(D.printLocker());

  }
}

// CombinationLock class
class CombinationLock {

  private int num1, num2, num3, dial;

  // constructor w/ no input arguments
  public CombinationLock() {
    num1 = 0;
    num2 = 0;
    num3 = 0;
    dial = 0;
  }

  //constructor w/ arguments for all attributes
  public CombinationLock(int num1, int num2, int num3, int dial) {
    this.num1 = num1;
    this.num2 = num2;
    this.num3 = num3;
    this.dial = dial;
  }

  // get methods
  public int getNum1() {
    return this.num1;
  }
  public int getNum2() {
    return this.num2;
  }
  public int getNum3() {
    return this.num3;
  }
  public int getDial() {
    return this.dial;
  }
  // set methods
  public void setNum1(int num1) {
    this.num1 = num1;
  }
  public void setNum2(int num2) {
    this.num2 = num2;
  }
  public void setNum3(int num3) {
    this.num3 = num3;
  }
  public void setDial(int dial) {
    this.dial = dial;
  }

  //method to print out all attributes
  public String printCombination() {
    return "\nCombination: [" + num1 + "-" + num2 + "-" + num3
      + "]" + "\nCurrent dial position: " + dial;
  }

  // resetDial method resets dial to 0
  public void resetDial() {
    dial = 0;
  }
  // turnLeft method turn dial # of ticks left from current
  public void turnLeft(int ticks) {
    if (ticks >= 40) {
      ticks %= 40;
    }
    dial += ticks;
    dial %= 40;
  }
  // turnRight method turn dial # of ticks right from current
  public void turnRight(int ticks) {
    if (ticks >= 40) {
      ticks %= 40;
    }
    if (dial - ticks <= 0) {
      dial = (dial + 40) - ticks;
    }
    else {
      dial -= ticks;
    }
  }
  // openLock method 3 input arguments passed as combination, return T/F
  public boolean openLock(int turn1, int turn2, int turn3) {
    return (this.num1 == turn1) && (this.num2 == turn2) && (this.num3 == turn3);
  }
}

// Locker class
class Locker {

  private int lockerNum, numOfBooks;
  private String student;
  private CombinationLock locker;

  // constructor w/ no input arguments
  public Locker() {
    lockerNum = 0;
    student = "";
    numOfBooks = 0;
    locker = new CombinationLock();
  }

  // constructor w/ arguments for all attributes
  public Locker(int lockerNum, String student, CombinationLock locker, int numOfBooks) {
    this.lockerNum = lockerNum;
    this.student = student;
    this.locker = locker;
    this.numOfBooks = numOfBooks;
  }

  // get methods
  public int getLockerNum() {
    return lockerNum;
  }
  public String getStudent() {
    return student;
  }
  public CombinationLock getLocker() {
    return locker;
  }
  public int getNumOfBooks() {
    return numOfBooks;
  }
  // set methods
  public void setLockerNum(int lockerNum) {
    this.lockerNum = lockerNum;
  }
  public void setStudent(String student) {
    this.student = student;
  }
  public void setLocker(CombinationLock locker) {
    this.locker = locker;
  }
  public void setNumOfBooks(int numOfBooks) {
    this.numOfBooks = numOfBooks;
  }

  // method to print out all attributes
  public String printLocker() {
    return "\nLocker #" + lockerNum + "\nStudent: " + student
    + locker.printCombination() + "\n" + numOfBooks + " books inside.";
  }
  // putBookInLocker method adds one book, no input arg, no return
  public void putBookInLocker() {
    numOfBooks++;
  }
  // removeBookFromLocker method, remove one book, return T/F
  public boolean removeBookFromLocker() {
    numOfBooks--;
    if (numOfBooks >= 0)
      return true;
    else
      numOfBooks = 0;
      return false;
  }
  // openLocker method, reads 3 ints, print success/failure
  public void openLocker() {

    Scanner input = new Scanner(System.in);
    int turn1, turn2, turn3;

    System.out.println("\nFirst number to turn to:");
    turn1 = input.nextInt();
    System.out.println("\nSecond number to turn to:");
    turn2 = input.nextInt();
    System.out.println("\nThird number to turn to:");
    turn3 = input.nextInt();

    if(locker.openLock(turn1, turn2, turn3))
      System.out.println("\nSuccess! You have opened the locker.");
    else
      System.out.println("\nFailure! Combination is incorrect.");

    input.close();
  }

}
