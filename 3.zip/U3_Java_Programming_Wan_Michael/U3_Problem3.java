/*
Michael Wan
10/08/17

CSC 201 (E05M)
Unit 3: Programming Problem 3 (Book)
U3_Problem3.java

Purpose:
Create a class called Book w/ following properties and appropriate data types:
Title, Author, numberOfPages
Create a second class called Volume with following properties and appropriate
data types:
volumeName, numberOfBooks, and Book[]
The Book[] contains an array of book objects
After creating these two classes, write an application DemoVolume to test the
classes.
*/

/* Pseudocode:
1) Create Book class and define appropriate data types
  Title, Author, numberOfPages
  constructor method
  toString() method
2) Create Volume class and define appropriate data types
  volumeName, numberOfBooks, Book[]
  constructor method
  toString() method
  getBookArray() method (returns a string of book properties for each book)
3) Create application called DemoVolume to test
  Create an array of book objects to be added to the volume
  Create a volume object called volume1
  Display the properties of volume1
*/

public class U3_Problem3 {

  public static void main(String[] args) {

    // DemoVolume to create array of book objects
    Book b1 = new Book("Superman, the Caped Hero","George Washington",512);
    Book b2 = new Book("Batman, the Masked Crusader","James Madison",746);
    Book b3 = new Book("Spiderman, the Friendly Neighbor","George Mason",369);
    Book b4 = new Book("Wolverine, the Clawed Man","Thomas Edison",975);

    // create an array of book objects
    Book[] bArray1 = {b1,b2,b3,b4};

    // create a volume object called volume1
    Volume v1 = new Volume("volume1", bArray1.length, bArray1);

    // display properties of volume1
    System.out.println(v1);

  }
}

// Book class
class Book {

  // define appropriate data types
  private String title, author;
  private int numberOfPages;

  // constructor method
  public Book(String title, String author, int numberOfPages) {
    this.title = title;
    this.author = author;
    this.numberOfPages = numberOfPages;
  }

  // toString() method
  public String toString() {
    return "\'" + title + "\' by " + author + ". (" +numberOfPages + " pages)\n";
  }
}

// Volume class
class Volume {

  // define appropriate data types
  private String volumeName;
  private int numberOfBooks;
  private Book[] books;

  // constructor method
  public Volume(String volumeName, int numberOfBooks, Book[] books) {
    this.volumeName = volumeName;
    this.numberOfBooks = numberOfBooks;
    this.books = books;
  }

  // toString() method
  public String toString() {
    return "\nVolume: " + volumeName + "\nBooks: " + numberOfBooks + "\n\n"
    + getBookArray();
  }

  // getBookArray() method
  public String getBookArray() {
    String bookArray = "";
    for (int i=0; i<books.length; i++) {
      bookArray = bookArray+books[i].toString();
    }
    return bookArray;
  }

}
