/*
Michael Wan
10/08/17

CSC 201 (E05M)
Unit 3: Programming Problem 2 (Cycle)
U3_Problem2.java

Purpose:
[A] Create a class called "Cycle" with two integer variables as properties:
"numberOfWheels" and "weight." Create a constructor with two parameters
using the same variable names in the parameter list.
Create a separate application to test the class and display its properties.
Note: do not change names of instance variables or the variables listed in
constructor's parameter list.

[B] Edit your Cycle class by adding a default constructor which will assign
default values of 100 for numberOfWheels and 1000 for weight by invoking
a call to the other constructor. Modify application in [A] to test the class.
*/

/* Pseudocode:
1) Create Cycle class and define private instance variables
  constructor w/ two parameters using same variable names
  method to print out attributes
  test the class and display properties in main method
2) Edit Cycle class to include a default constructor which invokes previous
  constructor
  default constructor assigns values of 100 and 1000 for numberOfWheels and
  weight respectively
  modify test in main method to test the edited cycle class

*/

public class U3_Problem2 {

  public static void main(String[] args) {

    //test the class and display properties in main method
    Cycle c1 = new Cycle(18,550);
    System.out.println("Cycle 1: " + c1);

    Cycle c2 = new Cycle();
    System.out.println("Cycle 2: " + c2);

  }
}

// Cycle class
class Cycle {

  // private instance variables
  private int numberOfWheels, weight;

  // constructor w/ two parameters using same variable names
  public Cycle(int numberOfWheels, int weight) {
    this.numberOfWheels = numberOfWheels;
    this.weight = weight;
  }

  // default constructor which invokes previous constructor
  public Cycle() {
    this(100, 1000);
  }

  // method to print out all attributes
  public String toString() {
    return "[wheels: " + numberOfWheels + " | weight: " + weight
    + "]";
  }
}
